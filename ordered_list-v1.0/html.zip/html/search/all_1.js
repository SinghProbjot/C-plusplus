var searchData=
[
  ['begin_1',['begin',['../classordered__list.html#a132095a5a88cc5aae64c9866953e36a6',1,'ordered_list']]]
];
