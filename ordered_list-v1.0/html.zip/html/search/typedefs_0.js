var searchData=
[
  ['difference_5ftype_87',['difference_type',['../classordered__list_1_1const__iterator.html#a19e3c9cdda2756fdf3fcb8a1c2d78f30',1,'ordered_list::const_iterator']]]
];
