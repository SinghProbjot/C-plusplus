var indexSectionsWithContent =
{
  0: "abcdeimoprstvxy~",
  1: "ciop",
  2: "mo",
  3: "abcemopst~",
  4: "prxy",
  5: "diov",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends"
};

