var searchData=
[
  ['y_86',['y',['../structpoint.html#a9a82ca9504acabb1e30569f89c805471',1,'point']]]
];
